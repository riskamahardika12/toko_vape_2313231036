<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'VapeShop Indonesia')</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
        }
        
        nav {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        nav .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        nav .logo {
            color: white;
            font-size: 1.8rem;
            font-weight: bold;
            text-decoration: none;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            gap: 2rem;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.3s;
        }
        
        nav ul li a:hover {
            opacity: 0.8;
        }
        
        main {
            min-height: calc(100vh - 200px);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        footer {
            background: #2d3748;
            color: white;
            text-align: center;
            padding: 2rem 0;
            margin-top: 3rem;
        }
        
        footer p {
            margin: 0.5rem 0;
        }
    </style>
    @yield('styles')
</head>
<body>
    <nav>
        <div class="container">
            <a href="/" class="logo">🌬️ VapeStore</a>
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="/products">Produk</a></li>
                <li><a href="/about">Tentang Kami</a></li>
            </ul>
        </div>
    </nav>
    
    <main>
        @yield('content')
    </main>
    
    <footer>
        <div class="container">
            <p>&copy; 2025 Corner VapeStore. All rights reserved.</p>
            <p>Peringatan: Produk ini mengandung nikotin. Tidak untuk dijual kepada anak di bawah umur.</p>
        </div>
    </footer>
</body>
</html>