@extends('layouts.app')

@section('title', 'Home - VapeShop Indonesia')

@section('styles')
<style>
    .hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 4rem 0;
        text-align: center;
    }
    
    .hero h1 {
        font-size: 3rem;
        margin-bottom: 1rem;
    }
    
    .hero p {
        font-size: 1.2rem;
        margin-bottom: 2rem;
    }
    
    .btn {
        display: inline-block;
        padding: 0.8rem 2rem;
        background: white;
        color: #667eea;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        transition: transform 0.3s;
    }
    
    .btn:hover {
        transform: translateY(-3px);
    }
    
    .featured {
        padding: 3rem 0;
    }
    
    .featured h2 {
        text-align: center;
        margin-bottom: 2rem;
        font-size: 2rem;
    }
    
    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 2rem;
        margin-top: 2rem;
    }
    
    .product-card {
        background: white;
        border-radius: 10px;
        padding: 1.5rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        transition: transform 0.3s, box-shadow 0.3s;
    }
    
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 15px rgba(0,0,0,0.2);
    }
    
    .product-image {
        width: 100%;
        height: 200px;
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        margin-bottom: 1rem;
    }
    
    .product-card h3 {
        margin-bottom: 0.5rem;
        color: #2d3748;
    }
    
    .product-price {
        color: #667eea;
        font-size: 1.3rem;
        font-weight: bold;
    }
</style>
@endsection

@section('content')
<div class="hero">
    <div class="container">
        <h1>Selamat Datang di Corner VapeHouse</h1>
        <p>Temukan berbagai produk vape berkualitas dengan harga terbaik</p>
        <a href="/products" class="btn">Lihat Produk</a>
    </div>
</div>

<div class="featured">
    <div class="container">
        <h2>⭐ Produk Unggulan</h2>
        <div class="product-grid">
            @foreach($featured_products as $product)
            <div class="product-card">
                <div class="product-image">🌬️</div>
                <h3>{{ $product['name'] }}</h3>
                <p class="product-price">Rp {{ number_format($product['price'], 0, ',', '.') }}</p>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection