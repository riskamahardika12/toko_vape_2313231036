@extends('layouts.app')

@section('title', 'Tentang Kami - VapeShop Indonesia')

@section('styles')
<style>
    .page-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 3rem 0;
        text-align: center;
    }
    
    .page-header h1 {
        font-size: 2.5rem;
    }
    
    .about-section {
        padding: 3rem 0;
    }
    
    .about-content {
        max-width: 800px;
        margin: 0 auto;
    }
    
    .info-card {
        background: white;
        border-radius: 10px;
        padding: 2rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        margin-bottom: 2rem;
    }
    
    .info-card h2 {
        color: #667eea;
        margin-bottom: 1rem;
        font-size: 1.8rem;
    }
    
    .info-card p {
        line-height: 1.8;
        color: #4a5568;
        margin-bottom: 1rem;
    }
    
    .contact-info {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin-top: 2rem;
    }
    
    .contact-item {
        background: #f7fafc;
        padding: 1.5rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
    }
    
    .contact-item h3 {
        color: #2d3748;
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .contact-item p {
        color: #4a5568;
        margin: 0;
    }
    
    .warning-box {
        background: #fff5f5;
        border-left: 4px solid #f56565;
        padding: 1.5rem;
        border-radius: 8px;
        margin-top: 2rem;
    }
    
    .warning-box h3 {
        color: #c53030;
        margin-bottom: 0.5rem;
    }
    
    .warning-box p {
        color: #742a2a;
        margin: 0;
    }
</style>
@endsection

@section('content')
<div class="page-header">
    <div class="container">
        <h1>ℹ️ Tentang Kami</h1>
        <p>Kenali lebih dekat Corner VapeStore</p>
    </div>
</div>

<div class="about-section">
    <div class="container">
        <div class="about-content">
            <div class="info-card">
                <h2>🏪 {{ $store_info['name'] }}</h2>
                <p>{{ $store_info['description'] }}</p>
                <p>Toko Vape Store Dengan Varian Liquid Dan Mod</p>
            </div>
            
            <div class="info-card">
                <h2>📞 Hubungi Kami</h2>
                <div class="contact-info">
                    <div class="contact-item">
                        <h3>📍 Alamat</h3>
                        <p>{{ $store_info['address'] }}</p>
                    </div>
                    <div class="contact-item">
                        <h3>☎️ Telepon</h3>
                        <p>{{ $store_info['phone'] }}</p>
                    </div>
                    <div class="contact-item">
                        <h3>✉️ Email</h3>
                        <p>{{ $store_info['email'] }}</p>
                    </div>
                    <div class="contact-item">
                        <h3>🕐 Jam Buka</h3>
                        <p>Senin - Sabtu<br>09:00 - 21:00 WIB</p>
                    </div>
                </div>
            </div>
            
            <div class="warning-box">
                <h3>⚠️ Peringatan Penting</h3>
                <p>Produk vape mengandung nikotin yang dapat menyebabkan kecanduan. Produk ini TIDAK untuk dijual kepada anak di bawah umur (dibawah 18 tahun). Gunakan produk dengan bijak dan bertanggung jawab.</p>
            </div>
        </div>
    </div>
</div>
@endsection