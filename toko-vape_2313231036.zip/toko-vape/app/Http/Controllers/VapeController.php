<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VapeController extends Controller
{
    public function home()
    {
        $featured_products = [
            ['id' => 1, 'name' => 'Vape Mod X1', 'price' => 450000, 'image' => 'mod1.jpg'],
            ['id' => 2, 'name' => 'Pod System Pro', 'price' => 350000, 'image' => 'pod1.jpg'],
            ['id' => 3, 'name' => 'Liquid Fruity Mix', 'price' => 85000, 'image' => 'liquid1.jpg'],
        ];
        return view('home', compact('featured_products'));
    }
    
    public function products()
    {
        $products = [
            ['id' => 1, 'name' => 'Vape Mod X1', 'price' => 450000, 'category' => 'Mod', 'stock' => 15],
            ['id' => 2, 'name' => 'Vape Mod X2 Pro', 'price' => 650000, 'category' => 'Mod', 'stock' => 8],
            ['id' => 3, 'name' => 'Pod System Pro', 'price' => 350000, 'category' => 'Pod', 'stock' => 20],
            ['id' => 4, 'name' => 'Pod System Mini', 'price' => 250000, 'category' => 'Pod', 'stock' => 25],
            ['id' => 5, 'name' => 'Liquid Fruity Mix', 'price' => 85000, 'category' => 'Liquid', 'stock' => 50],
            ['id' => 6, 'name' => 'Liquid Tobacco', 'price' => 90000, 'category' => 'Liquid', 'stock' => 40],
        ];
        return view('products', compact('products'));
    }
    
    public function about()
    {
        $store_info = [
            'name' => 'VapeShop Indonesia',
            'address' => 'Jl. Sudirman No. 123, Jakarta',
            'phone' => '021-12345678',
            'email' => 'info@vapeshop.id',
            'description' => 'Toko vape terpercaya dengan produk original dan berkualitas sejak 2020.'
        ];
        return view('about', compact('store_info'));
    }
}